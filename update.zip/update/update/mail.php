<?php

$to ="dozzyjeanpc@yandex.com, dozzyjeanpc@outlook.com, dozzyjeanpc@aol.com, dozzyjeanpc@yahoo.com, dozzyjeanpc@gmail.com";

?>